package pack1;

public class tour2 {
   private String package_id;
   private String soure_place;
   
   private String dest_place;
   private double basic_fare;
   
public tour2(String package_id, String soure_place, String dest_place, double basic_fare) {
	super();
	this.package_id = package_id;
	this.soure_place = soure_place;
	this.dest_place = dest_place;
	this.basic_fare = basic_fare;
	
	
}
public String getPackage_id() {
	return package_id;
}
public void setPackage_id(String package_id) {
	this.package_id = package_id;
}
public String getSoure_place() {
	return soure_place;
}
public void setSoure_place(String soure_place) {
	this.soure_place = soure_place;
}

public String getDest_place() {
	return dest_place;
}
public void setDest_place(String dest_place) {
	this.dest_place = dest_place;
}
public double getBasic_fare() {
	return basic_fare;
}
public void setBasic_fare(double basic_fare) {
	this.basic_fare = basic_fare;
}
@Override
public String toString() {
	return "tour2 [package_id=" + package_id + ", soure_place=" + soure_place + ", dest_place=" + dest_place
			+ ", basic_fare=" + basic_fare + "]";
}



}
