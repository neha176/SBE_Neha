package pack1;
import java.io.*; 
public class tour {
	public static void main(String[] arg) throws NumberFormatException, IOException {
    System.out.print("Tour Management"+'\n');
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    while(true) {
    
    	System.out.println("Press 1 to insert data");
    	System.out.println("Press 2 to display data");
    	System.out.println("Press 3 to get cost");
    	System.out.println("Press 4 to exit");
    	int c =Integer.parseInt(br.readLine());
    	outer2:
    	if(c==1) {
    		System.out.println("Enter Package ID");
    		String pid = br.readLine();
    		if(pid.length() != 7)
    			{System.out.print("Wrong ID"+'\n');
    			break outer2;}
    		System.out.println("Enter source place");
    		String sp = br.readLine();
    		if(sp.isEmpty() || sp.isBlank())
    		{
    			System.out.print("All fields are compulsory"+'\n');
    			break outer2;
    		}
    		System.out.println("Enter Destination place");
    		String dp = br.readLine();
    		if(dp.isEmpty() || dp.isBlank())
    		{
    			System.out.print("All fields are compulsory"+'\n');
    			break outer2;
    		}
    		System.out.println("Enter basic fare");
    		double fare = Double.parseDouble(br.readLine());
    		tour2 t2 = new tour2(pid,sp,dp,fare);
    		boolean ans = DAO.insert(t2);
    		if(ans) {
    			System.out.print("Added Successfully"+'\n');
    		}else
    		{
    			System.out.print("Try Again"+'\n');
    		}
    		
    		} else if (c==2) {
    		DAO.show();
    	} else if (c==3) {
    		System.out.print("Enter Source");
    		String c1 = br.readLine();
    		System.out.print("Enter Destination");
    		String c2 = br.readLine();
    		logic lg = new logic(c1,c2);
    		DAO.cost(lg);
;    	} else if (c==4) {
    		break;
    	}else {
    		
    	} 		
    	System.out.print("Thank You "+'\n');
    }
	}
}
