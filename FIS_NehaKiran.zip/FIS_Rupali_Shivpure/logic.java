package pack1;

public class logic {
  private String source;
  private String dest;
  

  public logic(String source, String dest) {
	super();
	this.source = source;
	this.dest = dest;
	
}

public String getSource() {
	return source;
}

public void setSource(String source) {
	this.source = source;
}

public String getDest() {
	return dest;
}

public void setDest(String dest) {
	this.dest = dest;
}



@Override
public String toString() {
	return "logic [source=" + source + ", dest=" + dest + "]";
}
   
}
