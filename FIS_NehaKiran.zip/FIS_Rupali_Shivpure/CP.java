package pack1;
import java.sql.*;
public class CP {
	static Connection con;
    public static Connection createC() {
    	//driver load
    	try {
    	Class.forName("com.mysql.jdbc.Driver");
    	String user= "root";
    	String pass = "rps@12345";
    	String url = "jdbc:mysql://localhost:3306/abc";
    	con= DriverManager.getConnection(url,user,pass);
    }
    	catch (Exception e) {
    	  e.printStackTrace();	
    	}
    	return con;
  }
}
